"""Consumer adapter: signing stays behind a configured custody-provider process."""

import base64
import json
import secrets
import subprocess
import time
from .core import Denied, canonical


def b64url(data):
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


class WalletSigner:
    def __init__(self, config):
        self.config = config

    def sign(self, message):
        # argv contains only the configured provider command, never secrets or messages.
        request = {
            "operation": "sign",
            "wallet_ref": self.config["wallet_ref"],
            "key_id": self.config["key_id"],
            "algorithm": "EdDSA",
            "message": base64.b64encode(message).decode(),
        }
        result = subprocess.run(
            self.config["command"],
            input=canonical(request),
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            check=True,
            timeout=30,
        )
        if len(result.stdout) > 4096:
            raise Denied("invalid_wallet_provider_response")
        return json.loads(result.stdout)["signature"]

    def assertion(self, client_id, token_endpoint):
        now = int(time.time())
        head = b64url(
            canonical({"alg": "EdDSA", "typ": "JWT", "kid": self.config["key_id"]})
        )
        body = b64url(
            canonical(
                {
                    "iss": client_id,
                    "sub": client_id,
                    "aud": token_endpoint,
                    "iat": now,
                    "exp": now + 30,
                    "jti": secrets.token_urlsafe(24),
                }
            )
        )
        signature = base64.b64decode(
            self.sign((head + "." + body).encode()), validate=True
        )
        return head + "." + body + "." + b64url(signature)
