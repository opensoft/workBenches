"""Restricted Smallstep signing client; no token or key is sent through argv."""

import base64
import json
import secrets
import struct
import time
from pathlib import Path
import jwt
import requests
from cryptography.hazmat.primitives import serialization
from .core import Denied, digest


class Issuer:
    def __init__(self, config):
        self.config = config

    def sign(self, body, decision):
        cfg = self.config
        now = int(time.time())
        key_id = digest(
            {
                "identity": decision["identity"]["id"],
                "task": body["task_id"],
                "grant": body["grant_id"],
                "request": digest(body),
                "policy": decision["policy_version"],
            }
        )
        claims = {
            "iss": cfg["provisioner"],
            "sub": key_id,
            "aud": cfg["url"].rstrip("/") + "/1.0/ssh/sign",
            "iat": now,
            "nbf": now - 5,
            "exp": now + 30,
            "jti": secrets.token_urlsafe(24),
            "step": {
                "ssh": {
                    "certType": "user",
                    "keyID": key_id,
                    "principals": [decision["principal"]],
                }
            },
            "ssh_principal": decision["principal"],
            "ssh_extensions": decision.get("extensions", {}),
        }
        token = jwt.encode(
            claims,
            Path(cfg["provisioner_key_file"]).read_bytes(),
            algorithm="ES256",
            headers={"kid": cfg["provisioner_key_id"]},
        )
        key = serialization.load_ssh_public_key(body["public_key"].encode())
        raw = (
            key.public_bytes(
                serialization.Encoding.OpenSSH, serialization.PublicFormat.OpenSSH
            )
            .decode()
            .split()[1]
        )
        response = requests.post(
            cfg["url"].rstrip("/") + "/1.0/ssh/sign",
            json={
                "publicKey": raw,
                "ott": token,
                "certType": "user",
                "keyID": key_id,
                "principals": [decision["principal"]],
                "validAfter": "0s",
                "validBefore": str(decision["ttl"]) + "s",
            },
            verify=cfg["root_file"],
            timeout=15,
        )
        response.raise_for_status()
        result = response.json()
        cert = result["crt"]
        if isinstance(cert, dict):
            cert = cert["certificate"]
        # step-ca returns the SSH wire certificate encoded in base64.
        blob = base64.b64decode(cert)
        n = struct.unpack(">I", blob[:4])[0]
        kind = blob[4 : 4 + n].decode()
        if kind != "ssh-ed25519-cert-v01@openssh.com":
            raise Denied("unexpected_certificate_type")
        text = kind + " " + cert
        parsed = serialization.load_ssh_public_identity(text.encode())
        parsed.verify_cert_signature()
        expected_ca = serialization.load_ssh_public_key(
            Path(cfg["ssh_user_ca_public_file"]).read_bytes()
        )
        encoding = (serialization.Encoding.OpenSSH, serialization.PublicFormat.OpenSSH)
        if parsed.signature_key().public_bytes(*encoding) != expected_ca.public_bytes(
            *encoding
        ):
            raise Denied("unexpected_signing_ca")
        if (
            parsed.public_key().public_bytes(*encoding) != key.public_bytes(*encoding)
            or parsed.valid_principals != [decision["principal"].encode()]
            or parsed.type.value != 1
            or parsed.key_id.decode() != key_id
        ):
            raise Denied("unexpected_certificate_scope")
        if parsed.extensions != {
            k.encode(): v.encode() for k, v in decision.get("extensions", {}).items()
        }:
            raise Denied("unexpected_certificate_extensions")
        if (
            parsed.valid_before > now + decision["ttl"] + 5
            or parsed.valid_before <= now
            or parsed.valid_after > now + 5
        ):
            raise Denied("unexpected_certificate_validity")
        return {
            "certificate": text,
            "serial": str(parsed.serial),
            "key_id": key_id,
            "expires_at": parsed.valid_before,
        }
