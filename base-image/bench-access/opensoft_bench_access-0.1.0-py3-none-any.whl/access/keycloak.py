"""Verify JWTs and query current Keycloak account/client role assignments."""

import json
import time
from pathlib import Path
import jwt
import requests
from .core import Denied


class Keycloak:
    def __init__(self, config):
        self.config = config
        self.issuer = config["issuer"].rstrip("/")
        self.transport_realm = config.get("admin_realm_url", self.issuer).replace("/admin/realms/", "/realms/").rstrip("/")
        self.jwks = jwt.PyJWKClient(self.transport_realm + "/protocol/openid-connect/certs")

    def verify(self, token):
        try:
            key = self.jwks.get_signing_key_from_jwt(token)
            claims = jwt.decode(
                token,
                key.key,
                algorithms=["RS256"],
                audience=self.config["audience"],
                issuer=self.issuer,
                options={"require": ["exp", "iat", "sub", "azp", "aud", "iss"]},
            )
            if time.time() - claims["iat"] > 300:
                raise Denied("token_too_old")
            return claims
        except jwt.PyJWTError as exc:
            raise Denied("invalid_token") from exc

    def _service_token(self):
        cfg = self.config
        key = Path(cfg["reader_key_file"]).read_bytes()
        now = int(time.time())
        import secrets

        assertion = jwt.encode(
            {
                "iss": cfg["reader_client_id"],
                "sub": cfg["reader_client_id"],
                "aud": self.issuer + "/protocol/openid-connect/token",
                "iat": now,
                "exp": now + 30,
                "jti": secrets.token_urlsafe(24),
            },
            key,
            algorithm="EdDSA",
            headers={"kid": cfg["reader_key_id"]},
        )
        response = requests.post(
            self.transport_realm + "/protocol/openid-connect/token",
            data={
                "grant_type": "client_credentials",
                "client_id": cfg["reader_client_id"],
                "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
                "client_assertion": assertion,
            },
            timeout=10,
        )
        response.raise_for_status()
        return response.json()["access_token"]

    def live_roles(self, claims, identity):
        cfg = self.config
        headers = {"Authorization": "Bearer " + self._service_token()}
        base = cfg["admin_realm_url"].rstrip("/")

        def get(path):
            resp = requests.get(base + path, headers=headers, timeout=10)
            resp.raise_for_status()
            return resp.json()

        user = get("/users/" + claims["sub"])
        if not user.get("enabled"):
            raise Denied("keycloak_user_disabled")
        if identity["class"] == "agent":
            client = get("/clients/" + identity["keycloak_client_uuid"])
            if not client.get("enabled") or client["clientId"] != identity["client_id"]:
                raise Denied("keycloak_client_disabled")
            owner = get(
                "/clients/" + identity["keycloak_client_uuid"] + "/service-account-user"
            )
            if owner["id"] != claims["sub"]:
                raise Denied("service_account_binding_mismatch")
        return {
            role["name"]
            for role in get(
                "/users/"
                + claims["sub"]
                + "/role-mappings/clients/"
                + cfg["audience_client_uuid"]
                + "/composite"
            )
        }
