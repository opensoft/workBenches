"""bench-access: explicit environment, isolated credentials, strict host verification."""

import argparse
import base64
import json
import os
import secrets
import subprocess
import sys
import tempfile
import time
from pathlib import Path
import requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from .core import canonical, signed_message
from .wallet import WalletSigner


def protected_write(path, value):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(value)


def main():
    parser = argparse.ArgumentParser(prog="bench-access")
    parser.add_argument(
        "--config",
        default=os.environ.get("BENCH_ACCESS_CONFIG", "/etc/workbenches/access.json"),
    )
    parser.add_argument("--env", required=True, choices=["qa", "prod"])
    parser.add_argument(
        "command", choices=["doctor", "login", "targets", "explain", "ssh"]
    )
    parser.add_argument("target", nargs="?")
    parser.add_argument("--account")
    parser.add_argument("--task-id", default="")
    parser.add_argument("--grant-id", default="")
    args = parser.parse_args()
    cfg = json.loads(Path(args.config).read_text())["environments"][args.env]
    if not cfg.get("enabled"):
        raise RuntimeError("environment_not_activated")
    if cfg.get("identity_class") not in ("agent", "human"):
        raise RuntimeError("unknown_identity_class")
    if not cfg["access_url"].startswith("https://") or not cfg[
        "token_endpoint"
    ].startswith("https://"):
        raise RuntimeError("https_required")
    session = Path(cfg["session_dir"])
    if not session.is_absolute():
        raise RuntimeError("session_dir_must_be_absolute")
    session.mkdir(parents=True, exist_ok=True, mode=0o700)
    if (
        session.is_symlink()
        or session.stat().st_uid != os.getuid()
        or session.stat().st_mode & 0o077
    ):
        raise RuntimeError("unsafe_session_directory")
    tokenfile = session / (args.env + "-token.json")
    if args.command == "doctor":
        response = requests.get(cfg["access_url"].rstrip("/") + "/healthz", timeout=10)
        response.raise_for_status()
        health = response.json()
        if (
            health.get("component") != "ssh-access"
            or health.get("environment") != args.env
        ):
            raise RuntimeError("private_route_or_environment_mismatch")
        print(
            json.dumps(
                {
                    "environment": args.env,
                    "access_url": cfg["access_url"],
                    "identity_class": cfg["identity_class"],
                    "trust_fingerprint": cfg["ca_fingerprint"],
                    "activated": True,
                }
            )
        )
        return
    if args.command == "login":
        if cfg["identity_class"] == "agent":
            assertion = WalletSigner(cfg["wallet"]).assertion(
                cfg["client_id"], cfg["token_endpoint"]
            )
            response = requests.post(
                cfg["token_endpoint"],
                data={
                    "grant_type": "client_credentials",
                    "client_id": cfg["client_id"],
                    "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
                    "client_assertion": assertion,
                },
                timeout=15,
            )
            response.raise_for_status()
            data = response.json()
        else:
            response = requests.post(
                cfg["device_endpoint"],
                data={"client_id": cfg["client_id"], "scope": "openid profile email"},
                timeout=15,
            )
            response.raise_for_status()
            auth = response.json()
            print(
                "Open "
                + auth["verification_uri"]
                + " and enter code "
                + auth["user_code"],
                file=sys.stderr,
            )
            deadline = time.monotonic() + min(auth["expires_in"], 300)
            while True:
                if time.monotonic() >= deadline:
                    raise RuntimeError("login_expired")
                time.sleep(max(auth.get("interval", 5), 5))
                response = requests.post(
                    cfg["token_endpoint"],
                    data={
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                        "client_id": cfg["client_id"],
                        "device_code": auth["device_code"],
                    },
                    timeout=15,
                )
                data = response.json()
                if response.ok:
                    break
                if data.get("error") == "slow_down":
                    auth["interval"] = auth.get("interval", 5) + 5
                elif data.get("error") != "authorization_pending":
                    raise RuntimeError("login_denied")
        # Never persist refresh tokens; a new login is required after five minutes.
        saved = {
            "token": data["access_token"],
            "expires_at": time.time() + min(data["expires_in"], 290),
        }
        tmp = session / (".token-" + secrets.token_hex(12))
        protected_write(tmp, json.dumps(saved))
        os.replace(tmp, tokenfile)
        print("Authenticated; access token stored in protected session directory.")
        return
    if tokenfile.is_symlink() or tokenfile.stat().st_mode & 0o077:
        raise RuntimeError("unsafe_token_file")
    saved = json.loads(tokenfile.read_text())
    if saved["expires_at"] <= time.time():
        raise RuntimeError("login_required")
    headers = {"Authorization": "Bearer " + saved["token"]}

    def api(method, path, body=None):
        response = requests.request(
            method,
            cfg["access_url"].rstrip("/") + path,
            headers=headers,
            json=body,
            timeout=20,
        )
        if not response.ok:
            # Never include a request, response headers or token in an error.
            error = response.json()
            raise RuntimeError(
                str(error.get("error", "request_denied"))
                + " correlation="
                + str(error.get("correlation_id", "unavailable"))
            )
        return response.json()

    if args.command in ("targets", "explain"):
        result = api("GET", "/v1/targets")
        if args.command == "explain":
            result["targets"] = [
                t for t in result["targets"] if t["target"] == args.target
            ]
            result["explanation"] = (
                "Listed accounts are authorized; absent targets require a current role, wallet grant and task scope."
            )
        print(json.dumps(result, indent=2))
        return
    if not args.target or not args.account:
        raise RuntimeError("target_and_account_required")
    challenge = api("POST", "/v1/challenge", {})["challenge"]
    key = Ed25519PrivateKey.generate()
    body = {
        "environment": args.env,
        "target": args.target,
        "account": args.account,
        "task_id": args.task_id,
        "grant_id": args.grant_id,
        "challenge": challenge,
        "public_key": key.public_key()
        .public_bytes(
            serialization.Encoding.OpenSSH, serialization.PublicFormat.OpenSSH
        )
        .decode(),
    }
    message = signed_message(body)
    body["ssh_signature"] = base64.b64encode(key.sign(message)).decode()
    if cfg["identity_class"] == "agent":
        body["wallet_signature"] = WalletSigner(cfg["wallet"]).sign(message)
    result = api("POST", "/v1/ssh/sign", body)
    certificate = serialization.load_ssh_public_identity(result["certificate"].encode())
    certificate.verify_cert_signature()
    trusted = serialization.load_ssh_public_key(cfg["ssh_user_ca_public_key"].encode())
    wire = (serialization.Encoding.OpenSSH, serialization.PublicFormat.OpenSSH)
    if certificate.signature_key().public_bytes(*wire) != trusted.public_bytes(*wire):
        raise RuntimeError("certificate_ca_mismatch")
    if certificate.public_key().public_bytes(*wire) != key.public_key().public_bytes(
        *wire
    ):
        raise RuntimeError("certificate_key_mismatch")
    prefix = (args.env + ":" + args.target + ":" + args.account + ":").encode()
    if len(certificate.valid_principals) != 1 or not certificate.valid_principals[
        0
    ].startswith(prefix):
        raise RuntimeError("certificate_scope_mismatch")
    if (
        certificate.valid_before <= time.time()
        or certificate.valid_after > time.time() + 5
    ):
        raise RuntimeError("certificate_not_valid")
    with tempfile.TemporaryDirectory(prefix="ssh-", dir=session) as directory:
        path = Path(directory)
        protected_write(
            path / "key",
            key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.OpenSSH,
                serialization.NoEncryption(),
            ).decode(),
        )
        protected_write(path / "key-cert.pub", result["certificate"] + "\n")
        protected_write(path / "known_hosts", result["known_hosts"] + "\n")
        cmd = [
            "ssh",
            "-F",
            "/dev/null",
            "-o",
            "BatchMode=yes",
            "-o",
            "IdentitiesOnly=yes",
            "-o",
            "IdentityAgent=none",
            "-o",
            "StrictHostKeyChecking=yes",
            "-o",
            "UserKnownHostsFile=" + str(path / "known_hosts"),
            "-o",
            "GlobalKnownHostsFile=/dev/null",
            "-o",
            "ForwardAgent=no",
            "-o",
            "ClearAllForwardings=yes",
            "-i",
            str(path / "key"),
            "-p",
            str(result["port"]),
            "-l",
            args.account,
            "--",
            result["hostname"],
        ]
        raise SystemExit(subprocess.call(cmd))


def entrypoint():
    try:
        main()
    except (Exception, KeyboardInterrupt) as exc:
        safe = str(exc) if isinstance(exc, RuntimeError) else "connection_failed"
        print("bench-access: " + safe, file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    entrypoint()
