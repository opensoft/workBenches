"""Fail-closed SSH authorization. All policy/state is administrator-owned input."""

import base64
import hashlib
import json
import re
import sqlite3
import time
from pathlib import Path
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


class Denied(Exception):
    pass


def canonical(value):
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def decode64(value):
    return base64.b64decode(value, validate=True)


def public_key(value):
    try:
        key = serialization.load_ssh_public_key(value.encode())
    except (ValueError, TypeError) as exc:
        raise Denied("invalid_public_key") from exc
    if not isinstance(key, Ed25519PublicKey):
        raise Denied("session_key_must_be_ed25519")
    return key


def signed_message(body):
    return canonical(
        {
            k: body[k]
            for k in (
                "environment",
                "target",
                "account",
                "task_id",
                "grant_id",
                "public_key",
                "challenge",
            )
        }
    )


class Nonces:
    def __init__(self, path):
        self.path = str(path)
        with sqlite3.connect(self.path) as db:
            db.execute(
                "CREATE TABLE IF NOT EXISTS nonce (value TEXT PRIMARY KEY, subject TEXT, expires INTEGER)"
            )

    def issue(self, subject):
        import secrets

        value = secrets.token_urlsafe(32)
        with sqlite3.connect(self.path) as db:
            db.execute("DELETE FROM nonce WHERE expires < ?", (int(time.time()),))
            db.execute(
                "INSERT INTO nonce VALUES (?, ?, ?)",
                (value, subject, int(time.time()) + 60),
            )
        return value

    def consume(self, value, subject):
        with sqlite3.connect(self.path) as db:
            result = db.execute(
                "DELETE FROM nonce WHERE value=? AND subject=? AND expires>=? RETURNING value",
                (value, subject, int(time.time())),
            ).fetchone()
        if result is None:
            raise Denied("invalid_or_consumed_challenge")


class Policy:
    def __init__(self, path, environment):
        self.path = Path(path)
        self.environment = environment

    def load(self):
        data = json.loads(self.path.read_text())
        empty = not any(
            data.get(k) for k in ("identities", "targets", "grants", "tasks")
        )
        if data.get("environment") != self.environment or (
            not empty and data.get("valid_until", 0) <= time.time()
        ):
            raise Denied("stale_or_wrong_environment_policy")
        return data

    def identity(self, claims, data):
        identity = data["identities"].get(claims.get("sub"))
        if (
            not identity
            or not identity.get("enabled")
            or identity["client_id"] != claims.get("azp")
        ):
            raise Denied("identity_not_enrolled")
        return identity

    def authorize(self, claims, live_roles, body, data=None):
        data = data or self.load()
        identity = self.identity(claims, data)
        if body.get("environment") != self.environment:
            raise Denied("wrong_environment")
        target = data["targets"].get(body.get("target"))
        if not target or not target.get("enabled"):
            raise Denied("target_not_enrolled")
        account = target["accounts"].get(body.get("account"))
        if not account or account["role"] not in live_roles:
            raise Denied("target_account_role_denied")
        token_roles = set(
            claims.get("resource_access", {}).get(data["audience"], {}).get("roles", [])
        )
        if account["role"] not in token_roles:
            raise Denied("token_role_denied")
        grant = None
        if identity["class"] == "agent":
            if identity.get("composition_hash") != identity.get(
                "attested_composition_hash"
            ):
                raise Denied("composition_mismatch")
            if identity.get("custody") not in (
                "holder_readable",
                "isolated_invocable",
                "isolated_per_use_authorized",
            ):
                raise Denied("unknown_custody")
            grant = data["grants"].get(body.get("grant_id"))
            task = data["tasks"].get(body.get("task_id"))
            obj = body["target"] + ":" + body["account"]
            if (
                not grant
                or grant.get("state") != "active"
                or grant.get("expires_at", 0) <= time.time()
            ):
                raise Denied("grant_inactive")
            if (
                grant.get("wallet_ref") != identity.get("wallet_ref")
                or grant.get("composition_hash") != identity["composition_hash"]
            ):
                raise Denied("wallet_grant_mismatch")
            if obj not in grant.get("objects", []) or "ssh.connect" not in grant.get(
                "acts", []
            ):
                raise Denied("grant_scope_denied")
            if (
                not task
                or task.get("expires_at", 0) <= time.time()
                or task.get("wallet_ref") != identity["wallet_ref"]
                or obj not in task.get("objects", [])
                or grant["grant_id"] not in task.get("grant_ids", [])
            ):
                raise Denied("task_scope_denied")
            if grant.get("authority_tier") not in ("act", "act_unsupervised"):
                raise Denied("unsupported_authority_tier")
            if (
                grant.get("authority_tier") == "act_unsupervised"
                and identity["custody"] != "isolated_per_use_authorized"
            ):
                raise Denied("custody_ceiling_exceeded")
        elif identity["class"] != "human":
            raise Denied("unknown_identity_class")
        for value in (
            self.environment,
            body["target"],
            body["account"],
            identity["id"],
        ):
            if not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", value):
                raise Denied("invalid_principal_component")
        ttl = min(
            600 if identity["class"] == "agent" else 3600,
            int(data["valid_until"] - time.time()),
        )
        if grant:
            ttl = min(
                ttl,
                int(grant["expires_at"] - time.time()),
                int(task["expires_at"] - time.time()),
            )
        if ttl < 30:
            raise Denied("authority_expiring")
        return {
            "identity": identity,
            "target": target,
            "account": account,
            "principal": ":".join(
                (self.environment, body["target"], body["account"], identity["id"])
            ),
            "ttl": ttl,
            "extensions": (
                {"permit-pty": ""} if account.get("allow_pty", False) else {}
            ),
            "policy_version": data["version"],
        }


def verify_proofs(body, identity):
    try:
        message = signed_message(body)
        public_key(body["public_key"]).verify(decode64(body["ssh_signature"]), message)
        if identity["class"] == "agent":
            public_key(identity["wallet_public_key"]).verify(
                decode64(body["wallet_signature"]), message
            )
    except (ValueError, KeyError, TypeError, InvalidSignature) as exc:
        # Cryptography signature failures expose no sensitive input.
        raise Denied("invalid_request_proof") from exc
