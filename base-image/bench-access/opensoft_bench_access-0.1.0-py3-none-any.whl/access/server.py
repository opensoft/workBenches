import json
import logging
import os
import secrets
from pathlib import Path
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from .core import Denied, Nonces, Policy, verify_proofs
from .issuer import Issuer
from .keycloak import Keycloak

config = json.loads(Path(os.environ["ACCESS_CONFIG"]).read_text())
policy = Policy(config["policy_file"], config["environment"])
nonces = Nonces(config["nonce_db"])
identity_provider = Keycloak(config["keycloak"])
issuer = Issuer(config["issuer"])
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
log = logging.getLogger("access.audit")
logging.basicConfig(level=logging.INFO)


@app.exception_handler(Denied)
async def denied(request, exc):
    correlation = secrets.token_hex(12)
    log.info(
        json.dumps(
            {"outcome": "denied", "reason": str(exc), "correlation": correlation}
        )
    )
    return JSONResponse(
        status_code=403, content={"error": str(exc), "correlation_id": correlation}
    )


@app.middleware("http")
async def bounded(request, call_next):
    length = request.headers.get("content-length")
    if length is None and request.method == "POST":
        return JSONResponse(
            status_code=411, content={"error": "content_length_required"}
        )
    if length and (not length.isdigit() or int(length) > 16384):
        return JSONResponse(status_code=413, content={"error": "request_too_large"})
    try:
        return await call_next(request)
    except Denied as exc:
        return await denied(request, exc)
    except Exception:
        log.error("authorization_dependency_unavailable")
        return JSONResponse(
            status_code=503, content={"error": "authorization_dependency_unavailable"}
        )


def authenticate(header):
    if not header or not header.startswith("Bearer "):
        raise Denied("bearer_token_required")
    claims = identity_provider.verify(header[7:])
    data = policy.load()
    identity = policy.identity(claims, data)
    roles = identity_provider.live_roles(claims, identity)
    return claims, data, identity, roles


@app.get("/healthz")
def health():
    return {
        "status": "ok",
        "component": "ssh-access",
        "environment": config["environment"],
    }


@app.get("/readyz")
def ready():
    policy.load()
    return {"status": "ok", "environment": config["environment"]}


@app.post("/v1/challenge")
def challenge(authorization: str = Header(default=None)):
    claims, _, _, _ = authenticate(authorization)
    return {"challenge": nonces.issue(claims["sub"]), "expires_in": 60}


@app.get("/v1/targets")
def targets(authorization: str = Header(default=None)):
    claims, data, identity, roles = authenticate(authorization)
    # Agent target discovery is filtered using live grant/task state too.
    found = []
    for target_id, target in data["targets"].items():
        for account in target["accounts"]:
            candidates = (
                [("", "")]
                if identity["class"] == "human"
                else [(g, t) for g in data["grants"] for t in data["tasks"]]
            )
            for grant, task in candidates:
                body = {
                    "environment": config["environment"],
                    "target": target_id,
                    "account": account,
                    "grant_id": grant,
                    "task_id": task,
                }
                try:
                    policy.authorize(claims, roles, body, data)
                except Denied:
                    continue
                found.append(
                    {
                        "target": target_id,
                        "account": account,
                        "hostname": target["hostname"],
                        "port": target.get("port", 22),
                        "known_hosts": target["known_hosts"],
                    }
                )
                break
    return {"environment": config["environment"], "targets": found}


@app.post("/v1/ssh/sign")
async def sign(request: Request, authorization: str = Header(default=None)):
    claims, data, identity, roles = authenticate(authorization)
    body = await request.json()
    required = {
        "environment",
        "target",
        "account",
        "task_id",
        "grant_id",
        "public_key",
        "challenge",
        "ssh_signature",
    }
    if (
        not isinstance(body, dict)
        or not required.issubset(body)
        or set(body) - required - {"wallet_signature"}
    ):
        raise Denied("invalid_request_fields")
    decision = policy.authorize(claims, roles, body, data)
    verify_proofs(body, identity)
    nonces.consume(body["challenge"], claims["sub"])
    result = issuer.sign(body, decision)
    log.info(
        json.dumps(
            {
                "outcome": "issued",
                "serial": result["serial"],
                "key_id": result["key_id"],
                "subject": claims["sub"],
                "identity": identity["id"],
                "wallet": identity.get("wallet_ref"),
                "composition": identity.get("composition_hash"),
                "grant": body["grant_id"],
                "task": body["task_id"],
                "target": body["target"],
                "account": body["account"],
                "environment": config["environment"],
                "policy": decision["policy_version"],
                "expires_at": result["expires_at"],
            }
        )
    )
    return {
        **result,
        "hostname": decision["target"]["hostname"],
        "port": decision["target"].get("port", 22),
        "known_hosts": decision["target"]["known_hosts"],
    }


# Reuse the existing private edge hostname/certificate without widening DNS.
public = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
public.add_exception_handler(Denied, denied)
public.middleware("http")(bounded)
public.get("/healthz")(health)
public.get("/readyz")(ready)
public.mount("/ssh-access", app)
